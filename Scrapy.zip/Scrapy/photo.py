import scrapy


class PhotoSpider(scrapy.Spider):
    name = 'photo'
    allowed_domains = ['www.vcg.com']
    start_urls = ['http://www.vcg.com/']

    def parse(self, response):
        pass
