# coding=gbk
"""
���ߣ�����
@ʱ��  : 2022/3/27 1:54
"""
# import logging
# logging.warning("This is a warning")

# import logging
# logger = logging.getLogger('test')
# logger.warning("This is a warning")


import logging
logger = logging.getLogger(__name__)
logger.warning("This is a warning")
