# coding =gbk
import urllib
import urllib.request
import os


class FengPipeline:
    def open_spider(self, item):
        print('start....')

    def process_item(self, item, spider):
        href = item['href']
        title = item['title']
        suffix = os.path.splitext(href)[-1]
        urllib.request.urlretrieve(href, filename="./photo/%s%s" % (title, suffix))
        print('photo----%s----save finished' % title)
        return item

    def close_spider(self, item):
        print('finish..')
