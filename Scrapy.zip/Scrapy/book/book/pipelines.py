# coding=utf-8

# import pymysql
#
#
# class BookPipeline:
#
#     # def __init__(self):
#     #     self.f = open('shu.json', 'w', encoding='utf-8')
#
#     def __init__(self):
#         # connection database
#         self.connect = pymysql.connect(host='localhost', user='root', passwd='123456',
#                                        db='book', charset='utf8mb4')  # 后面三个依次是数据库连接名、数据库密码、数据库名称
#         self.cursor = self.connect.cursor()
#         print('连接成功...')
#
#     def open_spider(self, item):
#         print('开始爬取....')
#
#     def process_item(self, item, spider):
#         sql = 'insert into dushu(title,info) values(%s,%s)'
#         self.cursor.execute(sql, (item['name'], item['info']))
#
#         # 提交到数据库
#         self.connect.commit()
#
#     def close_spider(self, spider):
#         # 关闭游标和连接
#         self.cursor.close()
#         self.connect.close()
#
#         # print(item)
#         # 将从spider文件传过来的数据使用dict()进行数据类型的转换成字典
#         # self.f.write(json.dumps(dict(item), ensure_ascii=False) + '\n')
#         # ensure_ascii=False设置防止中文乱码
#
#     def close_spider(self, item):
#         print('爬取结束...')

import pymysql
from twisted.enterprise import adbapi


# 异步更新操作
class BookPipeline(object):
    def __init__(self, db):
        self.db = db

    # 固定格式
    @classmethod
    def from_settings(cls, settings):
        adb = dict(
            host=settings['MYSQL_HOST'],
            db=settings['MYSQL_DB'],
            user=settings['MYSQL_USER'],
            password=settings['MYSQL_PASSWORD'],
            cursorclass=pymysql.cursors.DictCursor  # 指定cursor类型
        )

        # 连接数据池ConnectionPool，使用pymysql连接
        db = adbapi.ConnectionPool('pymysql', **adb)
        # 返回实例化参数
        return cls(db)

    def process_item(self, item, spider):
        self.db.runInteraction(self.charu, item)  # 指定操作方法和操作数据

    def charu(self, cursor, item):
        # 对数据库进行插入操作，并不需要commit，twisted会自动commit
        insert_sql = """
        insert into dushu(title, info) values (%s,%s)
        """

        cursor.execute(insert_sql, (item['name'], item['info']))
