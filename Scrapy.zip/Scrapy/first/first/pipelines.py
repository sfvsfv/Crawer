# coding=gbk
import urllib
import urllib.request
import os


class FirstPipeline(object):
    def open_spider(self, item):
        print('��ʼ��ȡ....')

    def process_item(self, item, spider):
        title = item['name']
        url = item['img']

        suffix = os.path.splitext(url)[-1]
        urllib.request.urlretrieve(url, filename="photo/%s%s" % (title, suffix))
        print('ͼƬ----%s----����ɹ�' % title)
        return item

    def close_spider(self, item):
        print('��ȡ����...')


