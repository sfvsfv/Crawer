# coding=gbk
"""
���ߣ�����
@ʱ��  : 2022/3/27 3:06
"""
from scrapy.selector import Selector

body = '<html><body><span>hello world</span></body></html>'

text=Selector(text=body).xpath('//span/text()').extract_first()

print(text)