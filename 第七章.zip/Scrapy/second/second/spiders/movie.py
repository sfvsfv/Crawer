# coding=gbk
import scrapy
from ..items import SecondItem


class MovieSpider(scrapy.Spider):
    name = 'movie'
    allowed_domains = ['www.ygdy8.com']
    start_urls = ['https://www.ygdy8.com/html/gndy/oumei/index.html']

    def parse(self, response):
        # ��Ӱ����,��Ӱ���
        tables = response.xpath('//table[@class="tbspan"]')
        for t in tables:
            # ������a��ǩ��extractƥ��ȫ�������.extract_firstƥ���һ��
            name = t.xpath('.//a[@class="ulink"]/text()').extract()[0]
            info = t.xpath('.//tr[last()]/td/text()').extract_first()
            # print(name)
            # print(info)
            url = 'https://www.ygdy8.com' + t.xpath('.//a[last()]/@href').extract_first()
            # print(url)
            item = SecondItem()
            item['name'] = name
            item['info'] = info

            yield scrapy.Request(url=url, callback=self.parse_detail, meta={'item': item})

    def parse_detail(self, response):
        # �������item���ݹ���
        item = response.meta['item']
        posters = response.xpath('//img/@src').extract_first()
        item['poster'] = posters
        yield item
