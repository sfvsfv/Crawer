import scrapy
from ..items import FengItem

class PhotoSpider(scrapy.Spider):
    name = 'photo'
    allowed_domains = ['www.vcg.com']
    start_urls = ['https://www.vcg.com/creative-image/fengjing/?page=1']

    def parse(self, response):
        figure = response.xpath("//div[@class='gallery_inner']/figure")

        for f in figure:
            item=FengItem()
            href=f.xpath('./a/img/@data-src').extract_first()
            url='http:'+href
            item['image_urls']=[url]  # ע������ӷ�����
            yield item



