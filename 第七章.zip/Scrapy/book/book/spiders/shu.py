# coding= utf-8
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule


class ShuSpider(CrawlSpider):
    name = 'shu'
    allowed_domains = ['www.dushu.com']
    start_urls = ['https://www.dushu.com/book/1175.html']

    rules = (
        Rule(LinkExtractor(allow=r'https://www.dushu.com/book/1175_\d+.html'), follow=True),
        Rule(LinkExtractor(allow=r'https://www.dushu.com/book/\d+/'), callback='parse_item'),
    )

    def parse_item(self, response):
        item = {}
        name = response.xpath("//div[@class='book-title']/h1/text()").extract_first()
        info = response.xpath("//div[@class='text txtsummary'][1]/text()").extract_first()
        item['name'] = name
        item['info'] = info
        yield item

