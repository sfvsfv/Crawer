import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule


class ChongSpider(CrawlSpider):
    name = 'chong'
    allowed_domains = ['www.ichong123.com']
    start_urls = ['http://www.ichong123.com/']
    # �б�ҳ����Ҫfollow ,����Ҫcallback;����ҳ�治��Ҫfollow,��Ҫcallback
    rules = (
        Rule(LinkExtractor(allow=r'/xiaogushi/index_\d+.html'), follow=True),
        Rule(LinkExtractor(allow=r'http://www.ichong123.com/news/\d+.html'), callback='parse_item'),
    )

    def parse_item(self, response):
        item = {}
        title = response.xpath("//div[@class='article-content']/h1/text()").extract_first()
        item['title'] = title
        return item
