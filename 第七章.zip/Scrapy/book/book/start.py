# coding=utf-8
"""
作者：川川
@时间  : 2022/3/28 15:33
"""
from scrapy import cmdline

# cmdline.execute(['scrapy', 'crawl', 'chong'])
cmdline.execute(['scrapy', 'crawl', 'shu'])