# coding=gbk
import scrapy
from ..items import ThreeItem

class ChongSpider(scrapy.Spider):
    name = 'chong'
    allowed_domains = ['www.ichong123.com']

    global num
    num = int(input('��Ҫ��ȡ����ҳ��'))

    # �ڶ�ҳ
    page = 2
    new_start = 'http://www.ichong123.com/news/xiaogushi/index_%d.html'
    start_urls = ['http://www.ichong123.com/news/xiaogushi/']  # ��ʼҳ

    def parse(self, response):
        li_list = response.xpath('//ul[@class="root-list-section"]/li')
        print('�б�����Ϊ��', len(li_list))
        item=ThreeItem()
        # ��ȡ��һҳ
        for li in li_list:
            # print(li)
            img_url = li.xpath('.//img/@lazy-src').extract_first()
            name = li.xpath('.//img/@alt').extract_first()
            info = li.xpath('.//p/text()').extract_first()
            item['img_url'] = img_url
            item['name'] = name
            item['info'] = info
            yield item

#��ȡ�ڶ�ҳ�Լ������ҳ��
        for i in range(self.page, num):
            print('������ȡ��ҳ��Ϊ��', i)

            if self.page == num:
                break
            # ����Request
            yield scrapy.Request(url=self.new_start % (i))
            self.page += 1


