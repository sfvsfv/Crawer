# coding=gbk
import scrapy
import logging

logger = logging.getLogger(__name__)

class TuSpider(scrapy.Spider):
    name = 'tu'
    allowed_domains = ['pic.netbian.com']
    start_urls = ['https://pic.netbian.com/4kfengjing/index.html']

    def parse(self, response):
        logger.warning('������һ������...')
        yield {}

        # img = response.xpath("//ul[@class='clearfix']/li")
        #
        # # ��ȡ��һҳ
        # for i in img:
        #     img = i.xpath('a/img/@src').extract_first()
        #     print(img)
