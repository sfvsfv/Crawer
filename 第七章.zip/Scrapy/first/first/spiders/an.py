# coding=gbk
# import scrapy
# from ..items import FirstItem
#
#
# class AnSpider(scrapy.Spider):
#     name = 'an'
#     allowed_domains = ['pic.netbian.com']  # ����������Χ
#     global num
#     num = int(input('��Ҫ��ȡ����ҳ��'))
#     # �ڶ�ҳ
#     page = 2
#     new_start = 'https://pic.netbian.com/4kfengjing/index_%d.html'
#     start_urls = ['https://pic.netbian.com/4kfengjing/index.html']  # ��ʼҳ
#
#     item = FirstItem()
#
#     def parse(self, response):
#         img = response.xpath("//ul[@class='clearfix']/li")
#         zhui = 'https://pic.netbian.com/'
#
#         item = FirstItem()  # ʹ��items�е�FirstItem
# #��ȡ��һҳ
#         for i in img:
#             img = i.xpath('a/img/@src').extract_first()
#             url = zhui + img
#             title = i.xpath('a/b/text()').extract_first()
#             item['name'] = title  # ��䵽
#             item['img'] = url
#             yield item
# #��ȡ�ڶ�ҳ�Լ������ҳ��
#         for i in range(self.page, num):
#             print('------------------', i)
#
#             if self.page == num:
#                 break
#             # ����Request
#             yield scrapy.Request(url=self.new_start % (i), callback=self.parse)
#             self.page += 1
#
import scrapy
from ..items import FirstItem
import os


class AnSpider(scrapy.Spider):
    name = 'an'
    allowed_domains = ['pic.netbian.com']  # ����������Χ
    global num
    num = int(input('��Ҫ��ȡ����ҳ��'))
    category = ['4kfengjing', '4kyouxi', '4kmein', '4kdongman', '4kdongwu', '4kyingshi']

    global lei
    lei = input('��ȡ�����ǣ�')

    # �ڶ�ҳ
    page = 2
    new_start = 'https://pic.netbian.com/{}/index_%d.html'.format(lei)
    start_urls = ['https://pic.netbian.com/{}/index.html'.format(lei)]  # ��ʼҳ

    item = FirstItem()

    def parse(self, response):
        img = response.xpath("//ul[@class='clearfix']/li")
        zhui = 'https://pic.netbian.com/'

        item = FirstItem()  # ʹ��items�е�FirstItem
        # ��ȡ��һҳ
        for i in img:
            img = i.xpath('a/img/@src').extract_first()
            url = zhui + img
            title = i.xpath('a/b/text()').extract_first()
            item['name'] = title  # ��䵽
            item['img'] = url
            yield item
        # ��ȡ�ڶ�ҳ�Լ������ҳ��
        for i in range(self.page, num):
            print('------------------', i)

            if self.page == num:
                break
            # ����Request
            yield scrapy.Request(url=self.new_start % (i), callback=self.parse)
            self.page += 1
